## 2 Component View

[Figure 1](#Ref_Configuration_proxy_component_diagram) shows the main components and interfaces of the X-Road configuration proxy. The components and the interfaces are described in detail in the following sections.



![](img/arc-cp_configuration_proxy_component_diagram.png)

Figure 1. Configuration proxy component diagram

Technologies used in the configuration proxy can be found here: \[[ARC-TEC](#Ref_ARC-TEC)\]