# X-Road: Configuration Proxy Architecture
**Technical Specification**

Version: 1.8  
01.06.2023

 Doc. ID: ARC-CP