### 2.5 Database

The Central Server holds the X-Road configuration in a PostgreSQL\[[3](#Ref_3)\] database. The database contains the security policy of the X-Road instance as well as a list of members, Security Servers, global groups and management services. For a detailed description of the Central Server configuration refer to \[[DM-CS](#Ref_DM-CS)\]. The configuration can be modified through the Central Server user interface and management services.



\[3\] See  for details.