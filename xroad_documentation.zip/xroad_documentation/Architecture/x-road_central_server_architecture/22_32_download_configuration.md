### 3.2 Download Configuration

Configuration clients download the generated global configuration files from the Central Server.

The configuration download interface is a synchronous interface provided by the Central Server. It is used by configuration clients such as Security Servers and configuration proxies.

The interface is described in more detail in \[[ARC-G](#Ref_ARC-G)\], \[[PR-GCONF](#Ref_PR-GCONF)\].