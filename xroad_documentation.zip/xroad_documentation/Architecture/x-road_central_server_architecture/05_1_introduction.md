## 1 Introduction

This document describes the architecture of the X-Road Central Server. For more information about X-Road and the role of the Central Server see \[[ARC-G](#Ref_ARC-G)\].

This document presents an overview of the components of the Central Server and the interfaces between these components. It is aimed at technical readers who want to acquire an overview of inner workings of the Central Server.