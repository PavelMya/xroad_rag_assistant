# X-Road: Central Server Architecture
**Technical Specification**

Version: 2.9  
Doc. ID: ARC-CS