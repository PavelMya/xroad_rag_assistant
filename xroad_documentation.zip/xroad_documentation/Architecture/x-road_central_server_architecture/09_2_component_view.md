## 2 Component View

[Figure 1](#Ref_Components_and_interfaces_of_the_X_Road_central_server) shows the main components and interfaces of the X-Road Central Server. The components and the interfaces are described in detail in the following sections.



![](img/arc-cs_components_and_interfaces_of_the_x_road_central_server.svg)

Figure 1. Components and interfaces of the X-Road Central Server

Technologies used in the Central Server can be found here: \[[ARC-TEC](#Ref_ARC-TEC)\]