# X-Road Security Architecture

**Technical Specification**

Version: 0.11
01.06.2023

Doc. ID: ARC-SEC

---