### 19.1 Common Regulations

Common European Union (EU) regulations:

  * EIDAS – Regulation (EU) No 910/2014 of the European Parliament and of the Council of 23 July 2014 on electronic identification and trust services for electronic transactions in the internal market. Refer to \[[EIDAS](#Ref_EIDAS)\]. 
  * GDPR – General Data Protection Regulation (EU) 2016/679 of the European Parliament and of the Council of 27 April 2016 on the protection of natural persons with regard to the processing of personal data and on the free movement of such data. Refer to \[[GDPR](#Ref_GDPR)\].