# Technical Specification

**X-Road Architecture**

Version: 1.14  
01.06.2023

Doc. ID: ARC-G

---