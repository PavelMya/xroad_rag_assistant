### 3.12 Operational Monitoring Query

The operational monitoring query interface is used by the X-Road security server to retrieve operational monitoring data from the operational monitoring daemon. The asynchronous RPC-style X-Road operational monitoring protocol \[[PR-OPMON](#Ref_PR-OPMON)\] (based on \[[PR-MESS](#Ref_PR-MESS)\]) is used.

The interface is described in more detail in \[[ARC-OPMOND](#Ref_ARC-OPMOND)\].