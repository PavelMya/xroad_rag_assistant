# X-Road: Security Server Architecture 

**Technical Specification** 

Version: 1.19
12.06.2024

Doc. ID: ARC-SS

---