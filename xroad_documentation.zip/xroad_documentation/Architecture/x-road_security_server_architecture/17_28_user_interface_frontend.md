### 2.8 User Interface Frontend

The security server user interface allows a user to manage the security server configuration. 

The user interface is a single page web application that makes requests to the management REST API to read and modify configuration.

The user interface fetches it's resources (images, stylesheets, javascript files) from the web application which
hosts the management REST API.