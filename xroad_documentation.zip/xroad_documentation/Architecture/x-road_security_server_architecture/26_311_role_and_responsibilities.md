#### 3.1.1 Role and responsibilities

Xroad-proxy-ui-api provides the Security Server user interface. It also provides the REST API that can be used for management operations. In addition, it provides the \[[ACME](#Ref_ACME)\] interface for receiving incoming ACME challenge requests from the ACME server.