### 2.4 Operational Monitoring Services

Provides methods that can be used by X-Road participants to get operational monitoring information of the security server.
It requests the data from the local opmonitor service via an SOAP XML request and mediates the SOAP XML response to the caller.

The component is a proxy addon.