### 2.5 Opmonitor

Opmonitor component collects operational monitoring information such as which services have been called, how many times, what was the size of the response, etc. 
The monitoring data is published via SOAP XML and (optional) JMX interfaces.

The component is a separate daemon process.