# Audit log events

Version: 1.14

Doc. ID: SPEC-AL