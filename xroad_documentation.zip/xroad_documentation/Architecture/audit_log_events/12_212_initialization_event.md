#### 2.1.2 Initialization Event

The audit log event related to initialization.

| Event                     | Data fields                                                                                                                                                                                                                        |
|---------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Initialize Central Server | centralServerAddress - the address of the Central ServerinstanceIdentifier - the instance identifier of the Central ServerhaNode - the name of the node in the cluster in the case of HA setup |