#### 2.1.1 Common Events

The audit log events related to the UI logging and the UI language settings.

| Event           | Data fields                                |
|-----------------|--------------------------------------------|
| Log in user     |                                            |
| Log out user    |                                            |
| Set UI language | * locale - the selected UI locale (e.g en) |