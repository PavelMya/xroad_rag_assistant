# X-Road technologies

**Technical Specification**

Version: 1.14
19.12.2023

Doc. ID: ARC-TEC

---