#### 2.2.1 Indexes

| Name                              | Columns                                    | Partial index details  |
| --------------------------------- |:------------------------------------------:| ----------------------:|
| last_archive_digestpk             | id                                         | N/A                    |
| last_archive_digest_groupname_key | groupname                                  | N/A                    |