# X-Road: Security Server Configuration Data Model

Version: 1.12
Doc. ID: DM-SS