#### 2.20.1 Indexes

| Name        | Columns           |
|:----------- |:-----------------:|
| index_security_server_clients_on_member_class_id | member_class_id |
| index_security_server_clients_on_server_client_id | server_client_id |
| index_security_server_clients_on_xroad_member_id | xroad_member_id |