### 2.24 TRUSTED_ANCHORS

Trusted anchor of a federation partner. A trusted anchor is the configuration anchor of the configuration source distributing the external configuration of a federation partner.

The record is created or modified exactly the same way as described in the documentation of table anchor_url_certs. The record is never modified.