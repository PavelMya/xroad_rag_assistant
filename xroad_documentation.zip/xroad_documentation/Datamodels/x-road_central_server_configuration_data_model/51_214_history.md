### 2.14 HISTORY

Operation (insertion, update or deletions of a record) on the tables of this database, for the purpose of auditing. Each row corresponds to the change of a single field.

The record is created in the manner described above in this document. The record can be neither modified nor deleted.