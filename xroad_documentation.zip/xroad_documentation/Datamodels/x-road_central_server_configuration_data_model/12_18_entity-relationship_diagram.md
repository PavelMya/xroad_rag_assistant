### 1.8 Entity-Relationship Diagram

The data model is described in two entity relationship diagrams (ERD). The first diagram contains tables related to Security Servers and Security Server clients. The second diagram contains the rest of the tables.

![Entity-Relationship Diagram](img/dm-cs-central-server-database-diagram.svg)

Figure 1. ERD describing the database tables in the Central Server database